import { fr } from "date-fns/locale";

export const dateLocale = fr;

export const formatOptions = {
  locale: fr,
};
